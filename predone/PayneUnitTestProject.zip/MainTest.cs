using Microsoft.VisualStudio.TestTools.UnitTesting;
using $safeprojectname$.Base;

namespace $safeprojectname$
{
    [TestClass]
    public partial class MainTest : TestBase
    {
        [TestMethod]
        [TestTraits(Trait.PlaceHolder)]
        public void TestMethod1()
        {
            // arrange
            

            // act


            // assert
        }
        [TestMethod]
        [TestTraits(Trait.PlaceHolder)]
        public void TestMethod2()
        {
            // TODO
        }
    }
}
